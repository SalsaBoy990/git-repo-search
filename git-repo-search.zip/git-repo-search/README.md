# git-repo-search
Wordpress plugin to implement Live Search in GitHub repositories using the GitHub API


Simple live search in GitHub repos with jQuery AJAX GitHub REST API: https://developer.github.com/v3/
