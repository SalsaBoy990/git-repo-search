<?php

define('AG_GIT_REPO_SEARCH_DEBUG', 0);

define('AG_GIT_REPO_SEARCH_LOGGING', 1);

define('AG_GIT_REPO_SEARCH_PLUGIN_DIR', plugin_dir_path(__FILE__));